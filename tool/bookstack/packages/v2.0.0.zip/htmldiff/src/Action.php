<?php namespace Ssddanbrown\HtmlDiff;

class Action
{
    const EQUAL = 'equal';
    const DELETE = 'delete';
    const INSERT = 'insert';
    const NONE = 'none';
    const REPLACE = 'replace';
}