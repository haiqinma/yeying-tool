<?php namespace Ssddanbrown\HtmlDiff;

class Mode
{
    const CHARACTER = 'character';
    const TAG = 'tag';
    const WHITESPACE = 'whitespace';
    const ENTITY = 'entity';
}